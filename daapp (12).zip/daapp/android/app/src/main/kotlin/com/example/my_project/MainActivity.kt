package com.flutterflow.daapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
